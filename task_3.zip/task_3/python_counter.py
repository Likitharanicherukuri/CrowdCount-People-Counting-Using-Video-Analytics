import cv2
import numpy as np

# ----------------------------
# Initialize HOG Person Detector
# ----------------------------
hog = cv2.HOGDescriptor()
hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

# ----------------------------
# Open Camera
# ----------------------------
cap = cv2.VideoCapture(0)

zones = []
drawing = False
start_point = None
fullscreen = False

# ----------------------------
# Mouse Callback Function
# ----------------------------
def draw_zone(event, x, y, flags, param):
    global drawing, start_point, zones

    if event == cv2.EVENT_LBUTTONDOWN:
        drawing = True
        start_point = (x, y)

    elif event == cv2.EVENT_LBUTTONUP:
        drawing = False
        end_point = (x, y)
        zones.append((start_point, end_point))


cv2.namedWindow("Camera")
cv2.setMouseCallback("Camera", draw_zone)

# ----------------------------
# Main Loop
# ----------------------------
while True:
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.resize(frame, (960, 720))

    # ----------------------------
    # Detect People
    # ----------------------------
    boxes, weights = hog.detectMultiScale(frame, winStride=(8, 8))
    total_people = len(boxes)

    # Draw detection boxes
    for (x, y, w, h) in boxes:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

    # ----------------------------
    # Draw Zones + Count Inside
    # ----------------------------
    for i, zone in enumerate(zones):
        (x1, y1), (x2, y2) = zone

        # Ensure correct rectangle direction
        x_min, x_max = min(x1, x2), max(x1, x2)
        y_min, y_max = min(y1, y2), max(y1, y2)

        cv2.rectangle(frame, (x_min, y_min), (x_max, y_max), (0, 0, 255), 2)

        zone_count = 0

        for (x, y, w, h) in boxes:
            center_x = x + w // 2
            center_y = y + h // 2

            if x_min < center_x < x_max and y_min < center_y < y_max:
                zone_count += 1

        cv2.putText(frame,
                    f"Zone {i+1} Count: {zone_count}",
                    (x_min, y_min - 10),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    (0, 0, 255),
                    2)

    # ----------------------------
    # Display UI Instructions
    # ----------------------------
    cv2.putText(frame, f"Total People: {total_people}", (20, 40),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)

    cv2.putText(frame, "Mouse Drag - Draw Zone", (20, 80),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    cv2.putText(frame, "D - Delete Last Zone", (20, 110),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    cv2.putText(frame, "R - Reset All Zones", (20, 140),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    cv2.putText(frame, "P - Save Screenshot", (20, 170),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    cv2.putText(frame, "F - Fullscreen Toggle", (20, 200),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    cv2.putText(frame, "Q - Quit", (20, 230),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

    cv2.imshow("Camera", frame)

    # ----------------------------
    # Keyboard Controls
    # ----------------------------
    key = cv2.waitKey(1) & 0xFF

    if key == ord('q'):
        break

    elif key == ord('d'):
        if len(zones) > 0:
            zones.pop()

    elif key == ord('r'):
        zones = []

    elif key == ord('p'):
        cv2.imwrite("screenshot.png", frame)

    elif key == ord('f'):
        fullscreen = not fullscreen
        if fullscreen:
            cv2.setWindowProperty("Camera", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
        else:
            cv2.setWindowProperty("Camera", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_NORMAL)

# ----------------------------
# Cleanup
# ----------------------------
cap.release()
cv2.destroyAllWindows()