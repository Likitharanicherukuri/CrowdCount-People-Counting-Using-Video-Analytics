import cv2
import json
import os
import time

ZONE_FILE = "zones.json"

zones = []
drawing = False
selected_zone = None
start_x, start_y = -1, -1
temp_rect = None
fullscreen = False

colors = [
    (0, 255, 0),
    (255, 0, 0),
    (0, 0, 255),
    (255, 255, 0),
    (255, 0, 255),
    (0, 255, 255)
]

# ---------------- SAVE & LOAD ---------------- #

def save_zones():
    with open(ZONE_FILE, "w") as f:
        json.dump(zones, f, indent=4)

def load_zones():
    if os.path.exists(ZONE_FILE):
        with open(ZONE_FILE, "r") as f:
            return json.load(f)
    return []

# ---------------- MOUSE HANDLER ---------------- #

def mouse_handler(event, x, y, flags, param):
    global drawing, start_x, start_y, temp_rect, selected_zone

    if event == cv2.EVENT_LBUTTONDOWN:
        drawing = True
        start_x, start_y = x, y

    elif event == cv2.EVENT_MOUSEMOVE and drawing:
        temp_rect = (start_x, start_y, x, y)

    elif event == cv2.EVENT_LBUTTONUP:
        drawing = False

        x1 = min(start_x, x)
        y1 = min(start_y, y)
        x2 = max(start_x, x)
        y2 = max(start_y, y)

        if abs(x2 - x1) > 10 and abs(y2 - y1) > 10:
            zones.append({"x1": x1, "y1": y1, "x2": x2, "y2": y2})
            save_zones()

        temp_rect = None

    elif event == cv2.EVENT_RBUTTONDOWN:
        selected_zone = None
        for i, z in enumerate(zones):
            if z["x1"] <= x <= z["x2"] and z["y1"] <= y <= z["y2"]:
                selected_zone = i
                break

# ---------------- INITIALIZATION ---------------- #

zones = load_zones()

cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("Camera not opening.")
    exit()

cv2.namedWindow("Video")
cv2.setMouseCallback("Video", mouse_handler)

# ---------------- MAIN LOOP ---------------- #

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # -------- Instructions --------
    instructions = [
        "Draw Zone: Click & Drag",
        "Right Click: Select Zone",
        "X: Delete Selected",
        "D: Delete Last",
        "R: Reset All",
        "S: Save Zones",
        "V: Screenshot",
        "F: Fullscreen",
        "Q: Quit"
    ]

    for i, text in enumerate(instructions):
        cv2.putText(frame, text, (10, 25 + i * 25),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6,
                    (0, 255, 255), 2)

    # -------- Draw Zones --------
    for i, z in enumerate(zones):
        color = colors[i % len(colors)]
        thickness = 4 if i == selected_zone else 2

        cv2.rectangle(frame,
                      (z["x1"], z["y1"]),
                      (z["x2"], z["y2"]),
                      color,
                      thickness)

        cv2.putText(frame,
                    f"Zone {i+1}",
                    (z["x1"], z["y1"] - 10),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.6,
                    color,
                    2)

    # -------- Temp Rectangle --------
    if temp_rect:
        cv2.rectangle(frame,
                      (temp_rect[0], temp_rect[1]),
                      (temp_rect[2], temp_rect[3]),
                      (200, 200, 200),
                      1)

    cv2.imshow("Video", frame)

    key = cv2.waitKey(1) & 0xFF

    if key == ord('q'):
        break

    elif key == ord('d') and zones:
        zones.pop()
        selected_zone = None
        save_zones()

    elif key == ord('r'):
        zones.clear()
        selected_zone = None
        save_zones()

    elif key == ord('s'):
        save_zones()
        print("Zones saved.")

    elif key == ord('x') and selected_zone is not None:
        zones.pop(selected_zone)
        selected_zone = None
        save_zones()

    elif key == ord('v'):
        filename = f"screenshot_{int(time.time())}.png"
        cv2.imwrite(filename, frame)
        print(f"Saved {filename}")

    elif key == ord('f'):
        fullscreen = not fullscreen
        if fullscreen:
            cv2.setWindowProperty("Video",
                                  cv2.WND_PROP_FULLSCREEN,
                                  cv2.WINDOW_FULLSCREEN)
        else:
            cv2.setWindowProperty("Video",
                                  cv2.WND_PROP_FULLSCREEN,
                                  cv2.WINDOW_NORMAL)

# ---------------- CLEANUP ---------------- #

save_zones()
cap.release()
cv2.destroyAllWindows()