import cv2
import math
import time
import csv

# =====================================
# CONFIGURATION OPTIONS
# =====================================

USE_CAMERA = True
VIDEO_PATH = "video.mp4"

ENABLE_CSV_SAVE = True
ENABLE_LINE = True
ENABLE_ZONES = True
ENABLE_DASHBOARD = True

DISTANCE_THRESHOLD = 50
SAVE_INTERVAL = 10  # seconds

# =====================================
# INITIAL SETUP
# =====================================

def init_video_source():
    if USE_CAMERA:
        return cv2.VideoCapture(0)
    else:
        return cv2.VideoCapture(VIDEO_PATH)

cap = init_video_source()

cv2.namedWindow("Advanced People Counter", cv2.WINDOW_NORMAL)

hog = cv2.HOGDescriptor()
hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

next_person_id = 0
tracked_people = {}
previous_positions = {}

entry_count = 0
exit_count = 0

line_y = 250

zones = {
    "Zone 1": (50, 50, 300, 300),
    "Zone 2": (350, 50, 600, 300)
}

zone_counts = {z: 0 for z in zones}
counted_ids = {z: set() for z in zones}

last_save_time = time.time()

# =====================================
# HELPER FUNCTIONS
# =====================================

def get_distance(p1, p2):
    return math.hypot(p1[0] - p2[0], p1[1] - p2[1])

def is_inside_zone(center, zone):
    x1, y1, x2, y2 = zone
    return x1 <= center[0] <= x2 and y1 <= center[1] <= y2

def reset_counts():
    global entry_count, exit_count, zone_counts, counted_ids
    entry_count = 0
    exit_count = 0
    zone_counts = {z: 0 for z in zones}
    counted_ids = {z: set() for z in zones}

# =====================================
# MAIN LOOP
# =====================================

while True:
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.resize(frame, (800, 600))

    boxes, weights = hog.detectMultiScale(frame, winStride=(8, 8))

    current_centers = []

    for (x, y, w, h) in boxes:
        cx = x + w // 2
        cy = y + h // 2
        current_centers.append((cx, cy))
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

    updated_tracked = {}

    for center in current_centers:

        matched_id = None

        for person_id, prev_center in tracked_people.items():
            if get_distance(center, prev_center) < DISTANCE_THRESHOLD:
                matched_id = person_id
                break

        if matched_id is None:
            matched_id = next_person_id
            next_person_id += 1

        updated_tracked[matched_id] = center

        # ENTRY / EXIT LOGIC
        if ENABLE_LINE and matched_id in previous_positions:
            prev_y = previous_positions[matched_id][1]
            curr_y = center[1]

            if prev_y < line_y and curr_y >= line_y:
                entry_count += 1
            elif prev_y >= line_y and curr_y < line_y:
                exit_count += 1

        previous_positions[matched_id] = center

        # ZONE LOGIC
        if ENABLE_ZONES:
            for zone_name, zone_rect in zones.items():
                if is_inside_zone(center, zone_rect):
                    if matched_id not in counted_ids[zone_name]:
                        zone_counts[zone_name] += 1
                        counted_ids[zone_name].add(matched_id)

        cv2.putText(frame, f"ID {matched_id}", center,
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)

    tracked_people = updated_tracked

    # DRAW LINE
    if ENABLE_LINE:
        cv2.line(frame, (0, line_y), (800, line_y), (0, 255, 255), 2)

    # DRAW ZONES
    if ENABLE_ZONES:
        for zone_name, (x1, y1, x2, y2) in zones.items():
            cv2.rectangle(frame, (x1, y1), (x2, y2), (255, 0, 0), 2)
            cv2.putText(frame, zone_name, (x1, y1-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 0), 2)

    # DASHBOARD
    if ENABLE_DASHBOARD:
        cv2.putText(frame, f"Total: {len(tracked_people)}", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        cv2.putText(frame, f"Entry: {entry_count}", (10, 60),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)
        cv2.putText(frame, f"Exit: {exit_count}", (10, 90),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)

        y_offset = 120
        for zone_name in zones:
            cv2.putText(frame, f"{zone_name}: {zone_counts[zone_name]}",
                        (10, y_offset),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 0), 2)
            y_offset += 30

    # SAVE CSV
    if ENABLE_CSV_SAVE and time.time() - last_save_time > SAVE_INTERVAL:
        with open("count_data.csv", "a", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                time.strftime("%H:%M:%S"),
                entry_count,
                exit_count,
                *zone_counts.values()
            ])
        last_save_time = time.time()

    cv2.imshow("Advanced People Counter", frame)

    # =====================================
    # KEYBOARD CONTROLS
    # =====================================

    key = cv2.waitKey(1) & 0xFF

    if key == ord('x'):
        ENABLE_LINE = not ENABLE_LINE

    elif key == ord('d'):
        ENABLE_DASHBOARD = not ENABLE_DASHBOARD

    elif key == ord('s'):
        ENABLE_CSV_SAVE = not ENABLE_CSV_SAVE

    elif key == ord('t'):
        ENABLE_ZONES = not ENABLE_ZONES

    elif key == ord('r'):
        reset_counts()

    elif key == ord('f'):
        cv2.setWindowProperty("Advanced People Counter",
                              cv2.WND_PROP_FULLSCREEN,
                              cv2.WINDOW_FULLSCREEN)

    elif key == ord('v'):
        cap.release()
        USE_CAMERA = not USE_CAMERA
        cap = init_video_source()

    elif key == ord('q') or key == 27:
        break

# =====================================
# CLEANUP
# =====================================

cap.release()
cv2.destroyAllWindows()